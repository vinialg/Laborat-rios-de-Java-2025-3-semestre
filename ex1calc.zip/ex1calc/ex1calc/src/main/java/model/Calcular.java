/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author unievgimenez
 */
public class Calcular {

    /*public static int numero01(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }*/
    public static double numero0(int number0){
        return number0;
    }
    
    public static double adicionar(double number1, double number2){
        return number1 + number2;
    }
    
    public static double subtrair(double number1, double number2){
        return number1 - number2;
    }
    
    public static double multiplicar(double number1, double number2){
        return number1 * number2;
    }
    
    public static double dividir(double number1, double number2){
        return number1 / number2;
    }
    
    
}
